<?php

 /*
 * 快范远程上传头像
 * ============================================================================
 * 版权所有: 快范网络，并保留所有权利。
 * 网站地址: http://www.kuaifan.net；
 * ----------------------------------------------------------------------------
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和
 * 使用；不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
*/


error_reporting(0);

if (strpos($_GET['wangluo'], "?")){
	$wangluoarr = explode('?', $_GET['wangluo']);
	$_GET['wangluo'] = $wangluoarr[0];
}
if (substr(strtolower($_GET['wangluo']),0,7) != "http://" && substr(strtolower($_GET['wangluo']),0,8) != "https://"){
	exit('-3');
}
$_ext = get_extension($_GET['wangluo']);
if ($_ext == 'jpg' || $_ext == 'gif' || $_ext == 'jpeg' || $_ext == 'png'){
	$uid = abs(intval($_GET['uid']));
	if ($uid < 1) exit('-2');
	$uid = sprintf("%09d", $uid);
	$dir1 = substr($uid, 0, 3);
	$dir2 = substr($uid, 3, 2);
	$dir3 = substr($uid, 5, 2);
	$avatardir = './data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/';
	$avatardir_ = get_file($_GET['wangluo'], $avatardir, 'time_'.substr($uid, -2).'.gif');
	makethumb($avatardir.'time_'.substr($uid, -2).'.gif', $avatardir, 200, 200, 0, substr($uid, -2).'_avatar_big.jpg');
	makethumb($avatardir.'time_'.substr($uid, -2).'.gif', $avatardir, 120, 120, 0, substr($uid, -2).'_avatar_middle.jpg');
	makethumb($avatardir.'time_'.substr($uid, -2).'.gif', $avatardir, 48, 48, 0, substr($uid, -2).'_avatar_small.jpg');
	fujian_del($avatardir.'time_'.substr($uid, -2).'.gif');
	exit('1');
}else{
	exit('-1');
}





/**
 * 删除文件
 */
 function fujian_del($str_file_path) {
	if (!unlink($str_file_path)){
		return false;
	}else{
		return true;
	}
}
/**
 * 获取文件扩展名
 */
function get_extension($file){
	$info = pathinfo($file);
	return $info['extension'];
}		
/**
 * 实现远程下载文件到本地
 *  @param: $url      要下载的文件地址
 *  @param: $folder   保存目录位置
 *  @param: $pic_name 保存文件名
 *  @param: $timeout  超时时间
 */
function get_file($url,$folder,$pic_name,$timeout = 300){
	set_time_limit($timeout); //限制最大的执行时间
	$destination_folder=$folder?$folder.'/':''; //文件下载保存目录
	$newfname=$destination_folder.$pic_name;//文件PATH
	$file=fopen($url,'rb');

	if($file){
		$newf=fopen($newfname,'wb');
		if($newf){
			while(!feof($file)){
				if (!fwrite($newf,fread($file,1024*8),1024*8)) return false;
			}
		}else{
			return false;
		}
		if($file) fclose($file);
		if($newf) fclose($newf);
		return true;
	}else{
		return false;
	}
}
/**
 * 图象缩略函数
 * 参数说明：
 * $srcfile 原图地址； 
 * $dir  新图目录 
 * $thumbwidth 缩小图宽最大尺寸 
 * $thumbheitht 缩小图高最大尺寸 
 * $ratio 默认等比例缩放 为1是缩小到固定尺寸。 
 * $dirname 保存到新文件名
*/ 
function makethumb($srcfile,$dir,$thumbwidth,$thumbheight,$ratio=0,$dirname='')
{ 
 //判断文件是否存在 
if (!file_exists($srcfile))return false;
 //生成新的同名文件，但目录不同 
$imgname=explode('/',$srcfile); 
$arrcount=count($imgname); 
if ($dirname){
	$dstfile = $dir.$dirname; 
}else{
	$dstfile = $dir.$imgname[$arrcount-1]; 
}
//缩略图大小 
$tow = $thumbwidth; 
$toh = $thumbheight; 
if($tow < 40) $tow = 40; 
if($toh < 45) $toh = 45;    
 //获取图片信息 
    $im =''; 
    if($data = getimagesize($srcfile)) { 
        if($data[2] == 1) { 
            $make_max = 0;//gif不处理 
            if(function_exists("imagecreatefromgif")) { 
                $im = imagecreatefromgif($srcfile); 
            } 
        } elseif($data[2] == 2) { 
            if(function_exists("imagecreatefromjpeg")) { 
                $im = imagecreatefromjpeg($srcfile); 
            } 
        } elseif($data[2] == 3) { 
            if(function_exists("imagecreatefrompng")) { 
                $im = imagecreatefrompng($srcfile); 
            } 
        } 
    } 
    if(!$im) return ''; 
    $srcw = imagesx($im); 
    $srch = imagesy($im); 
    $towh = $tow/$toh; 
    $srcwh = $srcw/$srch; 
    if($towh <= $srcwh){ 
        $ftow = $tow; 
        $ftoh = $ftow*($srch/$srcw); 
    } else { 
        $ftoh = $toh; 
        $ftow = $ftoh*($srcw/$srch); 
    } 
    if($ratio){ 
        $ftow = $tow; 
        $ftoh = $toh; 
    } 
    //缩小图片 
    if($srcw > $tow || $srch > $toh || $ratio) { 
        if(function_exists("imagecreatetruecolor") && function_exists("imagecopyresampled") && @$ni = imagecreatetruecolor($ftow, $ftoh)) { 
            imagecopyresampled($ni, $im, 0, 0, 0, 0, $ftow, $ftoh, $srcw, $srch); 
        } elseif(function_exists("imagecreate") && function_exists("imagecopyresized") && @$ni = imagecreate($ftow, $ftoh)) { 
            imagecopyresized($ni, $im, 0, 0, 0, 0, $ftow, $ftoh, $srcw, $srch); 
        } else { 
            return ''; 
        } 
        if(function_exists('imagejpeg')) { 
            imagejpeg($ni, $dstfile); 
        } elseif(function_exists('imagepng')) { 
            imagepng($ni, $dstfile); 
        } 
    }else { 
        //小于尺寸直接复制 
    copy($srcfile,$dstfile); 
    } 
    imagedestroy($im); 
    if(!file_exists($dstfile)) { 
        return ''; 
    } else { 
        return $dstfile; 
    } 
}
?>